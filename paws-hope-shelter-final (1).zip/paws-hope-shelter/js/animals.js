/*
  animals.js — Get involved page
  Loads the animal listings from data/animals.json, then lets the visitor
  search, filter and sort them and open a details modal for each animal.

  All text from the JSON file is inserted with textContent / setAttribute,
  never innerHTML, so the data cannot inject markup into the page.
*/
(function () {
  'use strict';

  var grid = document.getElementById('animal-grid');
  if (!grid) { return; }

  var tools = document.getElementById('animal-tools');
  var searchInput = document.getElementById('animal-search');
  var speciesSelect = document.getElementById('animal-species');
  var sortSelect = document.getElementById('animal-sort');
  var resetButton = document.getElementById('animal-reset');
  var countEl = document.getElementById('animal-count');
  var emptyEl = document.getElementById('animal-empty');
  var dialog = document.getElementById('animal-dialog');

  var animals = [];
  var longestWaitingId = null;

  /* ---------- small helpers ---------- */

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === 'text') { node.textContent = attrs[key]; }
      else if (key === 'class') { node.className = attrs[key]; }
      else { node.setAttribute(key, attrs[key]); }
    });
    (children || []).forEach(function (child) { node.appendChild(child); });
    return node;
  }

  function capitalise(word) { return word.charAt(0).toUpperCase() + word.slice(1); }

  function ageLabel(years) { return years + (years === 1 ? ' yr' : ' yrs'); }

  function tagText(animal) { return capitalise(animal.species) + ' · ' + ageLabel(animal.ageYears); }

  function arrivedLabel(animal) {
    var date = new Date(animal.arrived + 'T00:00:00');
    return date.toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' });
  }

  function enquireUrl(animal) {
    return 'enquiry.html?reason=adopt&animal=' + encodeURIComponent(animal.id);
  }

  function shareUrl(animal) {
    var base = window.location.origin + window.location.pathname;
    return base + '?animal=' + encodeURIComponent(animal.id);
  }

  /* ---------- building a card ---------- */

  function buildCard(animal) {
    var img = el('img', {
      src: 'images/' + animal.image + '-400.jpg',
      srcset: 'images/' + animal.image + '-400.jpg 400w, images/' + animal.image + '-800.jpg 800w',
      sizes: '(max-width: 768px) 90vw, (max-width: 1024px) 45vw, 30vw',
      alt: animal.alt,
      width: '400',
      height: '300',
      loading: 'lazy'
    });

    var isLongest = animal.id === longestWaitingId;
    var tag = el('span', {
      'class': 'tag' + (isLongest ? ' tag--urgent' : ''),
      text: isLongest ? 'Waiting longest' : tagText(animal)
    });

    var details = el('button', {
      'class': 'btn btn--ghost btn--small',
      type: 'button',
      'data-animal': animal.id,
      'aria-label': 'View details for ' + animal.name,
      text: 'Details'
    });
    var enquire = el('a', {
      'class': 'btn btn--outline btn--small',
      href: enquireUrl(animal),
      'aria-label': 'Enquire about ' + animal.name,
      text: 'Enquire'
    });

    return el('article', { 'class': 'card' }, [
      el('div', { 'class': 'card__media' }, [img]),
      el('div', { 'class': 'card__body' }, [
        el('h3', { 'class': 'card__title', text: animal.name }),
        el('p', { 'class': 'card__text', text: animal.summary }),
        el('div', { 'class': 'card__footer' }, [
          tag,
          el('div', { 'class': 'card__actions' }, [details, enquire])
        ])
      ])
    ]);
  }

  /* ---------- search, filter, sort ---------- */

  function matches(animal, query, species) {
    if (species !== 'all' && animal.species !== species) { return false; }
    if (!query) { return true; }
    var haystack = [
      animal.name, animal.species, animal.species + 's', animal.summary,
      animal.story, animal.traits.join(' '), ageLabel(animal.ageYears)
    ].join(' ').toLowerCase();
    return query.split(/\s+/).every(function (word) { return haystack.indexOf(word) !== -1; });
  }

  function sorter(mode) {
    switch (mode) {
      case 'youngest': return function (a, b) { return a.ageYears - b.ageYears || a.name.localeCompare(b.name); };
      case 'oldest':   return function (a, b) { return b.ageYears - a.ageYears || a.name.localeCompare(b.name); };
      case 'longest':  return function (a, b) { return a.arrived.localeCompare(b.arrived); };
      default:         return function (a, b) { return a.name.localeCompare(b.name); };
    }
  }

  function render() {
    var query = searchInput.value.trim().toLowerCase();
    var species = speciesSelect.value;
    var visible = animals
      .filter(function (a) { return matches(a, query, species); })
      .sort(sorter(sortSelect.value));

    grid.textContent = '';
    visible.forEach(function (animal) { grid.appendChild(buildCard(animal)); });

    emptyEl.hidden = visible.length !== 0;
    countEl.textContent = 'Showing ' + visible.length + ' of ' + animals.length +
      (animals.length === 1 ? ' animal' : ' animals');
    resetButton.hidden = !(query || species !== 'all' || sortSelect.value !== 'name');
  }

  function resetFilters() {
    searchInput.value = '';
    speciesSelect.value = 'all';
    sortSelect.value = 'name';
    render();
    searchInput.focus();
  }

  /* ---------- details modal ---------- */

  var lastOpened = null;

  function openDetails(id, trigger) {
    var animal = animals.filter(function (a) { return a.id === id; })[0];
    if (!animal || !dialog || typeof dialog.showModal !== 'function') { return; }

    lastOpened = animal;
    var img = dialog.querySelector('.modal__img');
    img.src = 'images/' + animal.image + '-800.jpg';
    img.srcset = 'images/' + animal.image + '-400.jpg 400w, images/' + animal.image + '-800.jpg 800w';
    img.alt = animal.alt;

    document.getElementById('animal-dialog-title').textContent = animal.name;
    document.getElementById('animal-dialog-meta').textContent =
      tagText(animal) + ' · At the shelter since ' + arrivedLabel(animal);
    document.getElementById('animal-dialog-story').textContent = animal.story;

    var traitList = document.getElementById('animal-dialog-traits');
    traitList.textContent = '';
    animal.traits.forEach(function (trait) { traitList.appendChild(el('li', { 'class': 'tag', text: trait })); });

    var enquire = document.getElementById('animal-dialog-enquire');
    enquire.href = enquireUrl(animal);
    enquire.textContent = 'Enquire about ' + animal.name;
    document.getElementById('animal-dialog-status').textContent = '';

    dialog.showModal();
    // Return focus to the button that opened the dialog when it closes.
    dialog.addEventListener('close', function restore() {
      dialog.removeEventListener('close', restore);
      if (trigger && document.body.contains(trigger)) { trigger.focus(); }
    });
  }

  function setupDialog() {
    if (!dialog) { return; }

    dialog.addEventListener('click', function (event) {
      // A click on the dim backdrop lands on the <dialog> itself.
      if (event.target === dialog || event.target.closest('[data-close]')) { dialog.close(); }
    });

    document.getElementById('animal-dialog-share').addEventListener('click', function () {
      if (!lastOpened) { return; }
      var status = document.getElementById('animal-dialog-status');
      var url = shareUrl(lastOpened);
      var data = {
        title: lastOpened.name + ' needs a home — Paws & Hope',
        text: 'Meet ' + lastOpened.name + ', ' + lastOpened.summary,
        url: url
      };
      if (navigator.share) {
        navigator.share(data).catch(function () { /* the visitor cancelled */ });
      } else if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(
          function () { status.textContent = 'Link copied. Paste it into a message or post.'; },
          function () { status.textContent = 'Copy this link: ' + url; }
        );
      } else {
        status.textContent = 'Copy this link: ' + url;
      }
    });

    grid.addEventListener('click', function (event) {
      var button = event.target.closest('button[data-animal]');
      if (button) { openDetails(button.getAttribute('data-animal'), button); }
    });
  }

  /* ---------- start ---------- */

  function start(list) {
    animals = list;
    var earliest = animals.slice().sort(function (a, b) { return a.arrived.localeCompare(b.arrived); })[0];
    longestWaitingId = earliest ? earliest.id : null;

    tools.hidden = false;
    var debounce;
    searchInput.addEventListener('input', function () {
      clearTimeout(debounce);
      debounce = setTimeout(render, 120);
    });
    speciesSelect.addEventListener('change', render);
    sortSelect.addEventListener('change', render);
    resetButton.addEventListener('click', resetFilters);
    tools.addEventListener('submit', function (event) { event.preventDefault(); });

    setupDialog();
    render();

    // A shared link such as services.html?animal=nala opens that animal.
    var wanted = new URLSearchParams(window.location.search).get('animal');
    if (wanted) { openDetails(wanted, null); }
  }

  fetch('data/animals.json', { headers: { Accept: 'application/json' } })
    .then(function (response) {
      if (!response.ok) { throw new Error('HTTP ' + response.status); }
      return response.json();
    })
    .then(function (list) {
      if (!Array.isArray(list) || list.length === 0) { throw new Error('Empty animal list'); }
      start(list);
    })
    .catch(function () {
      // Keep the static cards that are already in the HTML.
      if (countEl) {
        countEl.textContent = 'Showing our featured animals. The full list could not be loaded just now.';
      }
    });
})();
