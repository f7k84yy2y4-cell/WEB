/*
  map.js — contact.html
  Interactive Leaflet map (OpenStreetMap tiles) with a marker for each
  shelter site, popups, and buttons that fly the map to each location.
  If Leaflet cannot load, the static fallback inside <noscript> and the
  "Open in OpenStreetMap" link still work.
*/
(function () {
  'use strict';

  var container = document.getElementById('map');
  if (!container) { return; }

  if (typeof L === 'undefined') {
    // Leaflet did not load (offline, blocked, or the CDN is down).
    var note = document.getElementById('map-fallback');
    if (note) { note.hidden = false; }
    return;
  }

  // The map and its buttons start hidden so visitors without JavaScript
  // see the <noscript> fallback instead of an empty box.
  container.hidden = false;
  document.querySelectorAll('.map-controls').forEach(function (bar) { bar.hidden = false; });

  var locations = [
    {
      id: 'roodepoort',
      name: 'Main shelter, Roodepoort',
      address: '88 Kloof Road, Roodepoort, 1724',
      hours: 'Open daily 09:00–16:00',
      latlng: [-26.1625, 27.8725]
    },
    {
      id: 'greenstone',
      name: 'Greenstone adoption centre',
      address: 'Shop 22, Greenstone Mall, Edenvale, 1609',
      hours: 'Fri–Sun 10:00–17:00',
      latlng: [-26.1303, 28.1367]
    }
  ];

  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var map = L.map(container, {
    scrollWheelZoom: false,                    // do not hijack page scrolling
    dragging: !L.Browser.mobile                // one-finger drag should scroll the page on phones
  });

  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);

  var markers = {};
  locations.forEach(function (place) {
    var popup = document.createElement('div');
    var title = document.createElement('strong');
    title.textContent = place.name;
    var address = document.createElement('div');
    address.textContent = place.address;
    var hours = document.createElement('div');
    hours.textContent = place.hours;
    popup.appendChild(title);
    popup.appendChild(address);
    popup.appendChild(hours);

    markers[place.id] = L.marker(place.latlng, { title: place.name, alt: place.name }).addTo(map).bindPopup(popup);
  });

  map.fitBounds(L.latLngBounds(locations.map(function (p) { return p.latlng; })), { padding: [40, 40] });

  document.querySelectorAll('[data-map-focus]').forEach(function (button) {
    button.addEventListener('click', function () {
      var id = button.getAttribute('data-map-focus');
      var place = locations.filter(function (p) { return p.id === id; })[0];
      if (!place) { return; }
      map.flyTo(place.latlng, 15, { animate: !reduceMotion, duration: 0.8 });
      markers[id].openPopup();
      container.scrollIntoView({ block: 'nearest', behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  });

  document.querySelectorAll('[data-map-all]').forEach(function (button) {
    button.addEventListener('click', function () {
      map.closePopup();
      map.fitBounds(L.latLngBounds(locations.map(function (p) { return p.latlng; })), { padding: [40, 40], animate: !reduceMotion });
    });
  });
})();
