/*
  accordion.js — FAQ accordion
  Markup: .accordion > .accordion__item > h3 > button.accordion__trigger + .accordion__panel
  Without JavaScript every answer stays visible. With JavaScript the panels
  start collapsed and each trigger toggles its own panel (aria-expanded).
  Arrow Up/Down, Home and End move between triggers.
*/
(function () {
  'use strict';

  document.querySelectorAll('[data-accordion]').forEach(function (accordion) {
    var triggers = Array.prototype.slice.call(accordion.querySelectorAll('.accordion__trigger'));

    function setOpen(trigger, open) {
      var panel = document.getElementById(trigger.getAttribute('aria-controls'));
      if (!panel) { return; }
      trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
      panel.hidden = !open;
    }

    triggers.forEach(function (trigger) { setOpen(trigger, false); });
    accordion.classList.add('is-ready');

    triggers.forEach(function (trigger, index) {
      trigger.addEventListener('click', function () {
        setOpen(trigger, trigger.getAttribute('aria-expanded') !== 'true');
      });

      trigger.addEventListener('keydown', function (event) {
        var next = null;
        if (event.key === 'ArrowDown') { next = triggers[(index + 1) % triggers.length]; }
        else if (event.key === 'ArrowUp') { next = triggers[(index - 1 + triggers.length) % triggers.length]; }
        else if (event.key === 'Home') { next = triggers[0]; }
        else if (event.key === 'End') { next = triggers[triggers.length - 1]; }
        if (next) { event.preventDefault(); next.focus(); }
      });
    });

    var toggleAll = accordion.parentElement.querySelector('[data-accordion-toggle]');
    if (toggleAll) {
      toggleAll.hidden = false;
      toggleAll.addEventListener('click', function () {
        var openAll = triggers.some(function (t) { return t.getAttribute('aria-expanded') !== 'true'; });
        triggers.forEach(function (t) { setOpen(t, openAll); });
        toggleAll.textContent = openAll ? 'Collapse all' : 'Expand all';
      });
    }
  });
})();
