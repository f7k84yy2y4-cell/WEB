/*
  enquiry.js — enquiry.html
  1. Reads ?reason= and ?animal= from the URL so "Enquire" buttons pre-fill the form.
  2. Shows the adoption-only fields (animal, visit date) only for adoption enquiries.
  3. Validates, sends the form with AJAX, then shows a reply about cost and
     availability that matches what the visitor asked about.
*/
(function () {
  'use strict';

  var form = document.getElementById('enquiry-form');
  if (!form || !window.PH) { return; }

  var PH = window.PH;
  var checker = PH.initForm(form);
  var statusBox = document.getElementById('enquiry-status');
  var resultBox = document.getElementById('enquiry-result');
  var resultTitle = document.getElementById('enquiry-result-title');
  var resultBody = document.getElementById('enquiry-result-body');
  var resultActions = document.getElementById('enquiry-result-actions');
  var submitButton = document.getElementById('enquiry-submit');
  var message = form.elements.message;
  var visit = form.elements.visit;

  var REASONS = { adopt: 'Adoption', volunteer: 'Volunteering', sponsor: 'Donation or sponsorship', other: 'General enquiry' };
  var TIMES = { 'weekday-morning': 'weekday morning', 'weekday-afternoon': 'weekday afternoon', weekend: 'weekend' };

  /* ---------- 1. pre-fill from the URL ---------- */

  var params = new URLSearchParams(window.location.search);
  var wantedReason = params.get('reason');
  var wantedAnimal = params.get('animal');

  // Only accept values that already exist in the form, so a crafted link cannot inject anything.
  Array.prototype.forEach.call(form.elements.reason, function (radio) {
    if (radio.value === wantedReason) { radio.checked = true; }
  });
  Array.prototype.forEach.call(form.elements.animal.options, function (option) {
    if (option.value && option.value === wantedAnimal) {
      form.elements.animal.value = wantedAnimal;
      if (!wantedReason) { form.elements.reason.value = 'adopt'; }
    }
  });

  /* ---------- 2. fields that depend on the reason ---------- */

  var limits = PH.dateLimits();
  visit.min = limits.min;
  visit.max = limits.max;

  function currentReason() { return form.elements.reason.value; }

  function syncFields() {
    var reason = currentReason();
    Array.prototype.forEach.call(form.querySelectorAll('[data-show-for]'), function (field) {
      var show = field.getAttribute('data-show-for') === reason;
      field.hidden = !show;
      Array.prototype.forEach.call(field.querySelectorAll('input, select, textarea'), function (c) { c.disabled = !show; });
    });

    // "Something else" needs a proper message; for everything else it is optional.
    var needsMessage = reason === 'other';
    message.required = needsMessage;
    message.minLength = needsMessage ? 10 : 0;
  }

  Array.prototype.forEach.call(form.elements.reason, function (radio) {
    radio.addEventListener('change', syncFields);
  });
  syncFields();

  /* ---------- 3. the reply shown after a valid submission ---------- */

  function firstName(name) { return name.split(/\s+/)[0]; }

  function formatDate(iso) {
    return new Date(iso + 'T00:00:00').toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long' });
  }

  function buildReply(v, animalName) {
    var who = firstName(v.name);
    var reach = 'We will contact you on a ' + TIMES[v.availability] + ' within two working days.';

    if (v.reason === 'adopt') {
      var items = [
        'Cost: adoption costs R650. Every animal is vaccinated, sterilised and microchipped before they leave us.',
        animalName
          ? 'Availability: ' + animalName + ' is still waiting for a home. You can meet them at the main shelter in Roodepoort any day 09:00–16:00, or at the Greenstone adoption centre Friday to Sunday 10:00–17:00.'
          : 'Availability: we have 64 animals in our care right now. You can meet them at the main shelter any day 09:00–16:00, or at the Greenstone adoption centre Friday to Sunday 10:00–17:00.'
      ];
      if (v.visit) { items.push('Your visit: we have noted ' + formatDate(v.visit) + ' and will confirm it when we get in touch.'); }
      items.push(reach);
      return { title: 'Thank you, ' + who + '. Here is what happens next with your adoption enquiry', items: items };
    }

    if (v.reason === 'volunteer') {
      return {
        title: 'Thank you, ' + who + '. Here is what volunteering involves',
        items: [
          'Cost: volunteering is free.',
          'Availability: shifts run Monday to Sunday, morning and afternoon. Most people do one two-hour shift a week.',
          'Training takes a Saturday morning. Tebogo Radebe, our volunteer coordinator, will confirm the next date.',
          reach
        ]
      };
    }

    if (v.reason === 'sponsor') {
      return {
        title: 'Thank you, ' + who + '. Here is how donating and sponsoring works',
        items: [
          'Cost: R100 a month feeds one animal for a month. R250 a month covers vaccinations and deworming for three new arrivals.',
          'A once-off R780 covers the full intake cost for one animal. Sponsoring a kennel is R1 200 a month, with a plaque and quarterly updates.',
          'Availability: we can set up a monthly debit order at any time. We will send the details to ' + v.email + '.',
          reach
        ]
      };
    }

    return {
      title: 'Thank you, ' + who + '. We have your message',
      items: ['A member of the team will read it and reply. ' + reach]
    };
  }

  function emailText(v, animalName) {
    var lines = [
      'Name: ' + v.name,
      'Email: ' + v.email,
      'Phone: ' + (v.phone || 'not given'),
      'Area: ' + (v.area || 'not given'),
      'Enquiry about: ' + REASONS[v.reason]
    ];
    if (v.reason === 'adopt') {
      lines.push('Animal: ' + (animalName || 'not sure yet'));
      if (v.visit) { lines.push('Preferred visit: ' + v.visit); }
    }
    lines.push('Best time to reach: ' + TIMES[v.availability], '', 'Message:', v.message || '(none)');
    return lines.join('\n');
  }

  function showReply(v, animalName, sent) {
    var reply = buildReply(v, animalName);
    resultTitle.textContent = reply.title;
    resultBody.textContent = '';
    var list = PH.el('ul', { 'class': 'list-lined' });
    reply.items.forEach(function (text) { list.appendChild(PH.el('li', { text: text })); });
    resultBody.appendChild(list);

    resultActions.textContent = '';
    if (!sent) {
      var subject = '[Website enquiry] ' + REASONS[v.reason] + ' – ' + v.name;
      resultActions.appendChild(PH.el('a', {
        'class': 'btn btn--primary',
        href: PH.mailto(PH.config.contactEmail, subject, emailText(v, animalName)),
        text: 'Email this enquiry instead'
      }));
    }

    resultBox.hidden = false;
    resultBox.focus();
  }

  /* ---------- submit ---------- */

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    statusBox.hidden = true;
    resultBox.hidden = true;

    var bad = checker.validateAll();
    if (bad.length) {
      PH.setStatus(statusBox, 'error', [
        'Please fix the ' + bad.length + (bad.length === 1 ? ' field' : ' fields') + ' marked in red, then send the enquiry again.'
      ]);
      checker.focusFirst(bad);
      return;
    }

    var values = PH.values(form);
    var animalName = values.animal ? PH.optionText(form.elements.animal) : '';

    if (PH.isBot(form)) { showReply(values, animalName, true); return; }

    submitButton.disabled = true;
    submitButton.textContent = 'Sending…';

    PH.send(form).then(function (result) {
      submitButton.disabled = false;
      submitButton.textContent = 'Send enquiry';

      if (result.ok) {
        PH.setStatus(statusBox, 'success', ['Your enquiry has been sent.']);
      } else {
        PH.setStatus(statusBox, 'error', [
          'We could not send your enquiry online just now. Your reply is below, with a button to email it to us instead.'
        ]);
      }
      showReply(values, animalName, result.ok);
    });
  });
})();
