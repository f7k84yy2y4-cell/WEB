/*
  contact.js — contact.html
  Validates the message form, sends it with AJAX, then compiles the details
  into an e-mail addressed to PH.config.contactEmail (see forms.js). The
  visitor can open it in their own e-mail app with one click, or copy it.
*/
(function () {
  'use strict';

  var form = document.getElementById('contact-form');
  if (!form || !window.PH) { return; }

  var PH = window.PH;
  var checker = PH.initForm(form);
  var statusBox = document.getElementById('contact-status');
  var resultBox = document.getElementById('contact-result');
  var previewBox = document.getElementById('contact-email-preview');
  var mailtoLink = document.getElementById('contact-mailto');
  var copyButton = document.getElementById('contact-copy');
  var copyStatus = document.getElementById('contact-copy-status');
  var submitButton = document.getElementById('contact-submit');

  document.getElementById('contact-recipient').textContent = PH.config.contactEmail;

  var emailBody = '';

  function compileEmail(values, typeLabel) {
    var subject = '[Website] ' + typeLabel + ' from ' + values.cname;
    var body = [
      'Name: ' + values.cname,
      'Email: ' + values.cemail,
      'Phone: ' + (values.cphone || 'not given'),
      'Type of message: ' + typeLabel,
      '',
      values.cbody
    ].join('\n');
    return { subject: subject, body: body };
  }

  function showEmail(email) {
    emailBody = 'To: ' + PH.config.contactEmail + '\nSubject: ' + email.subject + '\n\n' + email.body;
    previewBox.textContent = emailBody;
    mailtoLink.href = PH.mailto(PH.config.contactEmail, email.subject, email.body);
    copyStatus.textContent = '';
    resultBox.hidden = false;
  }

  copyButton.addEventListener('click', function () {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(emailBody).then(
        function () { copyStatus.textContent = 'Email text copied.'; },
        function () { copyStatus.textContent = 'Could not copy. Select the text above and copy it by hand.'; }
      );
    } else {
      copyStatus.textContent = 'Could not copy. Select the text above and copy it by hand.';
    }
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    statusBox.hidden = true;
    resultBox.hidden = true;

    var bad = checker.validateAll();
    if (bad.length) {
      PH.setStatus(statusBox, 'error', [
        'Please fix the ' + bad.length + (bad.length === 1 ? ' field' : ' fields') + ' marked in red, then send the message again.'
      ]);
      checker.focusFirst(bad);
      return;
    }

    var values = PH.values(form);
    var typeLabel = PH.optionText(form.elements.csubject);
    var email = compileEmail(values, typeLabel);
    var first = values.cname.split(/\s+/)[0];
    var urgent = values.csubject === 'report';

    function finish(sent) {
      var lines = [];
      if (sent) {
        lines.push('Thank you, ' + first + '. We have received your message and will reply within two working days.');
      } else {
        lines.push('We could not send your message online just now. Use the email below to send it from your own email app.');
      }
      if (urgent) {
        lines.push('An animal in distress cannot wait for an email. Please also call our rescue line on ' + PH.config.emergencyPhone + ' now.');
      }
      PH.setStatus(statusBox, sent ? 'success' : 'error', lines);
      showEmail(email);
      resultBox.focus();
    }

    if (PH.isBot(form)) { finish(true); return; }

    submitButton.disabled = true;
    submitButton.textContent = 'Sending…';
    PH.send(form).then(function (result) {
      submitButton.disabled = false;
      submitButton.textContent = 'Send message';
      finish(result.ok);
    });
  });
})();
