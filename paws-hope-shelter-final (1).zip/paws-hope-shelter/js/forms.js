/*
  forms.js — shared form helpers (loaded before enquiry.js and contact.js)

  - PH.config      settings, including the recipient address for e-mails
  - PH.initForm    client-side validation with inline error messages
  - PH.send        AJAX (fetch) submission to the form's action URL
  - PH.mailto      builds a safe mailto: link from a subject and body

  Every rule is driven by the HTML attributes on the field (required,
  minlength, maxlength, type) plus a data-validate="name|email|phone|date"
  attribute, so the markup stays the single source of truth.
*/
(function () {
  'use strict';

  var PH = window.PH = window.PH || {};

  PH.config = {
    // The address that e-mails compiled by the contact form are sent to.
    contactEmail: 'hello@pawsandhope.example',
    emergencyPhone: '082 000 0005',
    submitTimeoutMs: 8000,
    maxVisitDays: 90
  };

  /* ---------- validation rules ---------- */

  function isoDate(date) {
    var m = String(date.getMonth() + 1).padStart(2, '0');
    var d = String(date.getDate()).padStart(2, '0');
    return date.getFullYear() + '-' + m + '-' + d;
  }

  PH.dateLimits = function () {
    var today = new Date();
    var last = new Date(today.getFullYear(), today.getMonth(), today.getDate() + PH.config.maxVisitDays);
    return { min: isoDate(today), max: isoDate(last) };
  };

  var rules = {
    name: function (value) {
      if (!/^[\p{L}][\p{L}\p{M}'’ .-]*$/u.test(value)) {
        return 'Names can only use letters, spaces, apostrophes, hyphens and full stops.';
      }
    },
    email: function (value) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
        return 'Enter an email address like name@example.com.';
      }
    },
    phone: function (value) {
      var digits = value.replace(/[\s\-()]/g, '');
      if (!/^(\+27|0027|0)[1-9][0-9]{8}$/.test(digits)) {
        return 'Enter a South African number such as 082 123 4567 or +27 82 123 4567.';
      }
    },
    date: function (value) {
      var parsed = new Date(value + 'T00:00:00');
      if (isNaN(parsed.getTime()) || isoDate(parsed) !== value) { return 'Enter a real date.'; }
      var limits = PH.dateLimits();
      if (value < limits.min) { return 'Choose today or a later date.'; }
      if (value > limits.max) { return 'Choose a date within the next ' + PH.config.maxVisitDays + ' days.'; }
    }
  };

  /* Returns an error message for one .field wrapper, or '' when it is fine. */
  function checkUnit(unit) {
    var radios = unit.querySelectorAll('input[type="radio"]');
    if (radios.length) {
      var anyChecked = Array.prototype.some.call(radios, function (r) { return r.checked; });
      var anyRequired = Array.prototype.some.call(radios, function (r) { return r.required; });
      return anyRequired && !anyChecked ? 'Please choose one option.' : '';
    }

    var control = unit.querySelector('input, select, textarea');
    if (!control || control.disabled) { return ''; }

    var value = control.value.trim();
    var label = control.getAttribute('data-label') || 'this field';

    if (value === '') {
      if (!control.required) { return ''; }
      return control.tagName === 'SELECT' ? 'Please choose ' + label + '.' : 'Please enter ' + label + '.';
    }
    if (control.minLength > 0 && value.length < control.minLength) {
      return 'Please use at least ' + control.minLength + ' characters (you have ' + value.length + ').';
    }
    if (control.maxLength > 0 && value.length > control.maxLength) {
      return 'Please keep this under ' + control.maxLength + ' characters.';
    }
    var rule = rules[control.getAttribute('data-validate')];
    return (rule && rule(value, control)) || '';
  }

  function showError(unit, message) {
    var errorEl = unit.querySelector('.field__error');
    if (errorEl) { errorEl.textContent = message; }
    unit.classList.toggle('is-invalid', Boolean(message));
    var controls = unit.matches('fieldset') ? [unit] : unit.querySelectorAll('input, select, textarea');
    Array.prototype.forEach.call(controls, function (c) {
      if (message) { c.setAttribute('aria-invalid', 'true'); } else { c.removeAttribute('aria-invalid'); }
    });
  }

  /* ---------- wiring a form up ---------- */

  PH.initForm = function (form) {
    var units = Array.prototype.slice.call(form.querySelectorAll('.field'));

    units.forEach(function (unit) {
      // Point each control at its hint and error text for screen readers.
      var ids = Array.prototype.map.call(unit.querySelectorAll('.field__hint, .field__error, .field__counter'),
        function (node) { return node.id; }).filter(Boolean).join(' ');
      var target = unit.matches('fieldset') ? unit : unit.querySelector('input, select, textarea');
      if (target && ids) { target.setAttribute('aria-describedby', ids); }

      var counter = unit.querySelector('.field__counter');
      var area = unit.querySelector('textarea[maxlength]');
      if (counter && area) {
        var update = function () { counter.textContent = area.value.length + ' / ' + area.maxLength; };
        area.addEventListener('input', update);
        update();
      }

      unit.addEventListener('focusout', function () { showError(unit, checkUnit(unit)); });
      var recheck = function () { if (unit.classList.contains('is-invalid')) { showError(unit, checkUnit(unit)); } };
      unit.addEventListener('input', recheck);
      unit.addEventListener('change', recheck);
    });

    return {
      /* Validates every visible field. Returns the invalid wrappers. */
      validateAll: function () {
        var bad = [];
        units.forEach(function (unit) {
          if (unit.hidden) { showError(unit, ''); return; }
          var message = checkUnit(unit);
          showError(unit, message);
          if (message) { bad.push(unit); }
        });
        return bad;
      },
      focusFirst: function (bad) {
        var first = bad[0];
        if (!first) { return; }
        var control = first.matches('fieldset') ? first.querySelector('input') : first.querySelector('input, select, textarea');
        if (control) { control.focus(); }
      }
    };
  };

  /* ---------- helpers used by the page scripts ---------- */

  PH.values = function (form) {
    var out = {};
    Array.prototype.forEach.call(form.elements, function (el) {
      if (!el.name || el.disabled || el.name === 'form-name' || el.name === 'bot-field') { return; }
      if (el.type === 'radio' && !el.checked) { return; }
      out[el.name] = el.value.trim();
    });
    return out;
  };

  PH.isBot = function (form) {
    var trap = form.elements['bot-field'];
    return Boolean(trap && trap.value);
  };

  PH.optionText = function (select) {
    var option = select.options[select.selectedIndex];
    return option ? option.textContent.trim() : '';
  };

  /* AJAX submission. Always resolves: { ok: true|false }. */
  PH.send = function (form) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, PH.config.submitTimeoutMs);
    var body = new URLSearchParams(new FormData(form)).toString();

    return fetch(form.getAttribute('action') || '/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body,
      signal: controller.signal
    }).then(function (response) {
      clearTimeout(timer);
      return { ok: response.ok };
    }).catch(function () {
      clearTimeout(timer);
      return { ok: false };
    });
  };

  PH.mailto = function (to, subject, body) {
    var cleanSubject = subject.replace(/[\r\n]+/g, ' ');
    return 'mailto:' + to + '?subject=' + encodeURIComponent(cleanSubject) +
      '&body=' + encodeURIComponent(body.replace(/\r?\n/g, '\r\n'));
  };

  PH.el = function (tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === 'text') { node.textContent = attrs[key]; }
      else if (key === 'class') { node.className = attrs[key]; }
      else { node.setAttribute(key, attrs[key]); }
    });
    (children || []).forEach(function (child) { node.appendChild(child); });
    return node;
  };

  PH.setStatus = function (box, kind, paragraphs) {
    box.textContent = '';
    box.className = 'form__status' + (kind === 'error' ? ' form__status--error' : '');
    paragraphs.forEach(function (node) {
      box.appendChild(typeof node === 'string' ? PH.el('p', { text: node }) : node);
    });
    box.hidden = false;
  };
})();
