# Paws & Hope Animal Shelter — Website

**Student:** Mafemani Mongwe  
**Student number:** 10516411  
**Module:** Web Development — Part 3: Enhancing Functionality and SEO  
**Live website:** https://pawsandhope-shelter.netlify.app/  
**GitHub repository:** Add your repository link before submitting.

## Project overview

Paws & Hope Animal Shelter is a five-page website created for a fictional volunteer-run non-profit organisation based in Johannesburg.

The website was developed in three parts. Part 1 focused on the project proposal and planning. Part 2 involved creating the website design using an external CSS stylesheet and making the pages responsive. Part 3 adds JavaScript functionality, form validation, search engine optimisation (SEO), security features and deployment.

Paws & Hope is a fictional organisation created for an academic project. All addresses, contact numbers, statistics and people mentioned on the website are fictional.

## Contents

1. Pages
2. File structure
3. CSS approach
4. Responsive design
5. Screenshot evidence
6. JavaScript functionality
7. Forms and validation
8. Search engine optimisation
9. Security and page speed
10. Deployment
11. Running the website locally
12. Changelog
13. References

---

## Pages

| Page | File | Purpose |
|---|---|---|
| Home | index.html | Introduces the shelter, displays animal listings, shelter statistics and donation information. |
| About us | about.html | Provides information about the shelter's history, mission, vision, spending and team. |
| Get involved | services.html | Displays animals available for adoption, volunteering opportunities and donation options. |
| Enquiry | enquiry.html | Allows visitors to enquire about adoption, volunteering and sponsorship. |
| Contact | contact.html | Provides contact information, an interactive map and a contact form. |
| Thank you | thanks.html | Displays a confirmation message after a successful form submission. |
| Not found | 404.html | Displays a friendly error message when a page cannot be found. |

## File structure

The website is organised into folders to keep the files easy to find and manage.

```text
paws-hope-shelter/
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── thanks.html
├── 404.html
├── robots.txt
├── sitemap.xml
├── _headers
├── css/
│   └── style.css
├── js/
│   ├── forms.js
│   ├── enquiry.js
│   ├── contact.js
│   ├── animals.js
│   ├── accordion.js
│   └── map.js
├── data/
│   └── animals.json
├── images/
├── docs/
│   └── screenshots/
└── README.md
```

The CSS folder contains the external stylesheet. The JavaScript folder contains the scripts used for the website's interactive features. The data folder stores the animal information, while the images folder contains the website pictures and favicon. The docs folder contains screenshots used as evidence of the website's development.

## CSS approach

I used one external stylesheet called css/style.css for all five main website pages. This makes it easier to maintain a consistent design because changes can be made in one place.

The stylesheet is connected to the HTML pages using the following code:

```html
<link rel="stylesheet" href="css/style.css">
```

I used BEM-style class names to organise the CSS. For example, .card represents the main component, .card__title represents an element inside the card, and .tag--urgent represents a variation of a tag. I also used layout classes such as .l-wrap and .l-grid.

The stylesheet starts with the website colours, fonts and spacing. It then includes the basic reset, text styles, layouts, buttons, cards, forms and footer.

The main colours are teal, yellow, white and cream. These colours help create a friendly and welcoming appearance that suits an animal shelter website. Poppins is used for headings, while Lato is used for normal text.

CSS Grid is used for larger layouts and card sections, while Flexbox is used for navigation, buttons and smaller content groups.

I also added hover, active and focus-visible states to give users visual feedback when interacting with links and buttons. A visible focus style helps keyboard users navigate the website. The prefers-reduced-motion setting also allows users who prefer less animation to have a more comfortable experience.

## Responsive design

I used a mobile-first approach when developing the website. This means the basic layout was designed for smaller screens before adding changes for tablets and desktops.

The website uses media queries to adjust its layout depending on the screen size.

| Screen size | Changes |
|---|---|
| Mobile | Content is displayed mostly in one column, buttons use the available width and navigation can wrap. |
| 480px and above | Buttons can appear next to each other, statistics are displayed in a row and forms can use two columns. |
| 768px and above | The header becomes horizontal, cards use two columns and content can appear beside images. |
| 1024px and above | Cards use three columns and the contact page can display the map next to other information. |

I used rem, em, percentage and ch units in different parts of the stylesheet instead of relying only on pixels. This helps the layout adjust to different screen sizes.

For images, I used srcset and sizes so that the browser can select an appropriate image depending on the screen size. The picture element is also used in the hero section to allow different images at different breakpoints.

Image width and height attributes were included to help prevent layout shifts. Images further down the page use lazy loading to improve loading performance.

## Screenshot evidence

Screenshots were captured at three different screen sizes using Chrome DevTools and the browser's responsive design tools.

The screenshots are stored in the docs/screenshots folder.

### Home page

- Desktop: 1440px — index-desktop.png
- Tablet: 768px — index-tablet.png
- Mobile: 390px — index-mobile.png

### Get involved page

- Desktop: 1440px — services-desktop.png
- Tablet: 768px — services-tablet.png
- Mobile: 390px — services-mobile.png

### Contact page

- Desktop: 1440px — contact-desktop.png
- Tablet: 768px — contact-tablet.png
- Mobile: 390px — contact-mobile.png

I tested the website by resizing the browser and using Chrome DevTools. I checked for horizontal scrolling, text that was difficult to read and buttons that were too small to use comfortably.

## Part 3: JavaScript functionality

JavaScript was added to make the website more interactive. I used plain JavaScript without a framework.

Each script checks whether the required page elements exist before running. This helps prevent errors on pages that do not use a particular feature.

| Feature | Page | Description |
|---|---|---|
| Dynamic content | services.html | Animal information is loaded from animals.json using fetch(). |
| Search and filter | services.html | Visitors can search for animals, filter by dogs or cats and sort the results. |
| Animal details modal | services.html | The Details button opens a dialog showing the animal's story and traits. |
| FAQ accordion | services.html | Visitors can expand and collapse five frequently asked questions. |
| Interactive map | contact.html | A Leaflet map displays the shelter locations using OpenStreetMap tiles. |

### Dynamic animal listings

The animal listings are stored in data/animals.json and loaded using JavaScript. This means new animals can be added by updating the JSON file instead of manually changing the HTML.

### Search and filtering

Visitors can search for animals using information such as their names, species, descriptions, stories, traits and ages.

They can also filter the listings to show dogs or cats and choose between four sorting options.

The result count is announced to screen readers, and a message appears when no animals match the search.

### Animal details modal

The Details button opens a dialog containing more information about the selected animal. Visitors can close the dialog using the Close button or the Escape key.

The Enquire button takes visitors to the enquiry page with the selected animal already filled in.

### FAQ accordion

The website includes five frequently asked questions. Visitors can expand and collapse each answer.

The accordion uses aria-expanded to communicate its current state. Keyboard users can also use the arrow keys, Home and End keys to move between questions.

Without JavaScript, the answers remain visible.

### Interactive map

The contact page uses Leaflet to display an interactive map with OpenStreetMap tiles. Markers and popups identify the different shelter locations.

Visitors can use buttons to move the map to each location. If Leaflet does not load, a link to OpenStreetMap is provided instead.

Screenshots showing these features are stored in docs/screenshots:

- part3-search-desktop.png
- part3-modal-mobile.png
- part3-accordion-desktop.png

## Part 3: Forms and validation

The website contains two main forms.

### Enquiry form

The enquiry page allows visitors to ask questions about adoption, volunteering and sponsorship.

Adoption-specific fields, such as the selected animal and preferred visit date, only appear when the visitor selects adoption as their enquiry type.

After a valid submission, the website displays a response based on the type of enquiry.

The responses provide information about adoption fees and meeting locations, volunteering opportunities and shifts, or donation and sponsorship options.

### Contact form

The contact page contains a form for general messages.

Visitors are asked to provide their name, email address, optional phone number, message type and message.

After validation, JavaScript collects the information and prepares an email using the recipient address stored in PH.config.contactEmail in js/forms.js.

Visitors can open the prepared email in their email application or copy the message.

When someone reports an animal in distress, the website also displays the emergency rescue number.

### HTML form elements

I used different HTML form elements, including text fields, email fields, telephone fields, date fields, radio buttons, dropdown menus and text areas.

Each field has a label to help visitors understand what information is required.

Related radio buttons are grouped using fieldset and legend elements.

### HTML5 validation

The forms use HTML5 validation attributes such as:

- required
- minlength
- maxlength
- type="email"
- type="tel"
- type="date"
- min and max

The novalidate attribute allows JavaScript to handle validation and display clearer error messages.

### JavaScript validation

The validation logic is stored in js/forms.js.

The following checks are performed:

- Names only accept letters, spaces, apostrophes, hyphens and full stops.
- Email addresses must follow a valid email format.
- Phone numbers must follow the South African format, for example 082 123 4567 or +27 82 123 4567.
- Visit dates must be between the current date and 90 days ahead.
- Message fields have character limits and display a live character counter.

Fields are checked when visitors leave them. Error messages disappear when the information is corrected.

If a visitor submits an incomplete or incorrect form, the page moves focus to the first field that needs attention.

The error messages are connected to their fields using aria-describedby and aria-invalid to improve accessibility.

### AJAX form submission

The forms use fetch() to send information to the form's action URL without reloading the page.

The forms are configured for Netlify Forms using data-netlify="true".

A success or failure message is displayed after submission. If the request fails, visitors can still use the email option to send their enquiry.

Requests have an eight-second timeout.

### Spam protection

A hidden honeypot field called bot-field is included in the forms.

This field is intended to catch automated spam submissions. If it is filled in, the website treats the submission as successful without sending the information.

Screenshots of the forms are stored in docs/screenshots:

- part3-enquiry-errors-desktop.png
- part3-enquiry-reply-desktop.png
- part3-contact-email-desktop.png

## Part 3: Search engine optimisation

Search engine optimisation was included to help people find the website when searching for animal shelters and adoption opportunities in Johannesburg.

### On-page SEO

| Technique | What was implemented |
|---|---|
| Keyword research | Keywords include animal shelter Johannesburg, adopt a dog Johannesburg, adopt a cat Roodepoort, volunteer at an animal shelter and sponsor a kennel. |
| Title tags | Each page has a unique title that describes its content. |
| Meta descriptions | Each page has its own short description to explain what visitors can expect. |
| Heading structure | Pages use one H1 heading, followed by H2 and H3 headings where appropriate. |
| Image optimisation | Images have descriptive file names, alternative text, width and height attributes, srcset and sizes. |
| URL structure | Short and descriptive file names are used for the website pages. |
| Internal linking | Navigation links connect all the pages, while content links visitors to related sections. |
| Mobile friendliness | The website uses a responsive layout and viewport settings. |
| Structured data | AnimalShelter JSON-LD provides information about the shelter to search engines. |
| Social previews | Open Graph and Twitter card tags help display website information when links are shared. |
| Language | The HTML pages use the en-ZA language setting. |

Each page targets one main keyword phrase, which is used naturally in its title, H1 heading, first paragraph and meta description.

### Additional files

- `robots.txt` lets crawlers read the site, blocks `/docs/` (assignment screenshots) and `/thanks.html`, and points to the sitemap.
- `sitemap.xml` lists the five public pages with a last-modified date and priority.
- `404.html` and `thanks.html` are marked `noindex` so they never appear in search results.

### Off-page strategy

These steps happen outside the code, and the site is fictional so none of them is carried out for real. This is how they would be done:

- **Backlinks:** ask Johannesburg pet businesses, vets, pet-food suppliers, schools and local community pages that already support the shelter to link to the adoption and donation pages. Submit the shelter to South African NPO and adoption directories. Offer rescue stories to local news sites and blogs, each with a link back.
- **Social media:** post each new animal with a photo and a link straight to its enquiry link on Facebook and Instagram, share volunteer days and success stories, and use local hashtags. The Open Graph tags make those shared links look good.
- **Local SEO:** claim a Google Business Profile for each of the two sites with correct address, hours and phone, keep the name, address and phone identical everywhere they appear, ask adopters for reviews, and list the shelter in local directories.

## Part 3: Security and page speed

**Security**
- `_headers` sets a Content Security Policy that only allows scripts and styles from the site, Leaflet's CDN and Google Fonts, plus `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy` and `Cross-Origin-Opener-Policy`.
- Leaflet's stylesheet and script are loaded with Subresource Integrity hashes, so a changed CDN file would be refused.
- Scripts build page content with `textContent` rather than `innerHTML`, so visitor input is never treated as HTML.
- The enquiry form only accepts `reason` and `animal` values from the URL that already exist in the form, so a crafted link cannot inject anything.
- External links use `rel="noopener noreferrer"`.
- GitHub Pages ignores `_headers`. On Netlify the headers apply automatically.

**Page speed**
- No framework or build step, so only a few small scripts load, and each page loads only the scripts it needs, using `defer`.
- Images are provided at several widths and lazy-loaded below the fold. Font loading uses `display=swap` and `preconnect`.
- `_headers` sets long cache times for images and short, revalidated cache times for CSS, JS and data.

## Deployment

The site is static, so it deploys without a build.

1. Push the repository to GitHub.
2. In Netlify choose **Add new site → Import an existing project**, pick the repository, leave the build command empty and set the publish directory to the repository root.
3. Netlify reads `_headers`, enables form handling through `data-netlify="true"` and serves `404.html` for unknown addresses.
4. If the site name Netlify gives you is different from `pawsandhope-shelter`, update the address in the `canonical` and `og:` tags, `sitemap.xml` and `robots.txt` (search for `pawsandhope-shelter.netlify.app`).

## Running the website locally



No build step and no dependencies. Clone the repository and open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Changelog

Entries are newest first. Use the format `YYYY-MM-DD — area — what changed (and why)`.

### Part 3 — Functionality and SEO

- **2026-10-19 — Documentation** — Added the Part 3 features, forms, SEO, security, deployment, changelog and reference sections to the README, with screenshot evidence.
- **2026-10-18 — Accessibility** — Fixed the heading order on `thanks.html` and `404.html` so headings no longer skip a level.
- **2026-10-18 — SEO and security** — Added unique titles, meta descriptions, canonical links, Open Graph tags and `AnimalShelter` structured data to every page. Added `robots.txt`, `sitemap.xml`, a favicon, `404.html`, `thanks.html` and the `_headers` file for security and caching.
- **2026-10-18 — Forms** — Replaced the static forms on `enquiry.html` and `contact.html` with validated forms: HTML5 attributes plus JavaScript checks, inline error messages, AJAX submission, a reply about cost and availability on the enquiry page, and a compiled email on the contact page.
- **2026-10-18 — Interactive map** — Replaced the embedded Google map on `contact.html` with a Leaflet map showing both sites. The old embed stays as a `<noscript>` fallback.
- **2026-10-18 — Dynamic content** — Moved the animal listings into `data/animals.json` and added search, species filter, sorting and a details modal to `services.html`.
- **2026-10-18 — Accordion** — Added the FAQ accordion to `services.html`.

### Part 2 feedback — corrections and improvements

After the Part 2 marks were released, I reviewed the submitted Part 2 pages and improved them. Each entry below says which file changed, what was wrong or missing, and what I did.

- **2026-10-18 — Page titles and meta descriptions (all five pages)** — The Part 2 titles were generic (for example "Enquiry — Paws & Hope Animal Shelter") and did not say what each page offers. I rewrote every title to include a keyword and the location, such as "Adopt a Pet in Johannesburg" and "Contact and Directions | Paws & Hope, Roodepoort", and rewrote each meta description as a short summary under about 160 characters.
- **2026-10-18 — Internal links (`index.html`, `about.html`, `services.html`, `enquiry.html`, `contact.html`)** — Pages only connected through the main navigation. I added "Meet the animals" and "Directions and opening hours" links to every footer, a call-to-action paragraph on `about.html` linking to donating, volunteering and adopting, a link from `enquiry.html` to the animal and volunteer sections, and a link from `contact.html` to the enquiry form.
- **2026-10-18 — Enquiry form (`enquiry.html`)** — The Part 2 form only had basic `required` attributes and no way to show errors. I added length limits, input types and `data-validate` rules, an error message under every field, a live character counter, an adoption-only section that appears when needed, and a result area for the reply. I also changed the label "Best day to reach you" to "Best time to reach you" to match the options in the dropdown, and marked the phone and area fields as optional.
- **2026-10-18 — Contact form (`contact.html`)** — The Part 2 form only had basic `required` attributes and did not submit anywhere. I added length limits, input types and validation rules, an error message under every field, a live character counter, a honeypot spam field, and an area that shows the email prepared for the shelter.
- **2026-10-18 — Map (`contact.html`)** — The Part 2 page used an embedded Google Maps frame, which could not mark both sites. I replaced it with an interactive Leaflet map showing the Roodepoort shelter and the Greenstone adoption centre. The original embed stays inside a `<noscript>` element as a fallback.
- **2026-10-18 — Get involved page (`services.html`)** — The animal cards were fixed HTML. I moved the animal information into `data/animals.json`, loaded it with JavaScript, and added search, filtering, sorting and a details window. I also added an FAQ section.
- **2026-10-18 — Stylesheet (`css/style.css`)** — Added styles for the new components (search bar, modal, accordion, form errors, result panel, map) so they follow the Part 2 colours, fonts and breakpoints. Added a `[hidden]` rule so hidden elements are never shown by other display rules, and a `.visually-hidden` class for the spam trap field.
- **2026-10-18 — Structured data and icons (all five pages)** — Added a favicon, canonical links, Open Graph tags and `AnimalShelter` structured data.

### Part 2 — CSS styling and responsive design

- **2026-09-16 — Documentation** — Added the CSS details, responsive sizes and screenshot information to the README.
- **2026-09-16 — Responsive images** — Added responsive image code so smaller screens can use smaller image files.
- **2026-09-16 — Responsive layout** — Added the mobile, tablet and desktop breakpoints.
- **2026-09-16 — Desktop layout** — Added the larger screen layout using Grid and Flexbox.
- **2026-09-16 — Base styles** — Added the basic reset, colours, fonts and text sizes.
- **2026-09-16 — Stylesheet** — Created the external stylesheet and linked it to all five pages.

## References

<!-- Update this list with the sources you actually used, in your module's referencing style. -->

- Mozilla Developer Network. *CSS: Cascading Style Sheets.* https://developer.mozilla.org/en-US/docs/Web/CSS
- Mozilla Developer Network. *Responsive images.* https://developer.mozilla.org/en-US/docs/Web/HTML/Responsive_images
- Mozilla Developer Network. *CSS Grid Layout* and *Flexbox.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Grid_Layout
- Web Content Accessibility Guidelines (WCAG) 2.2. https://www.w3.org/WAI/WCAG22/quickref/
- Google Fonts. *Poppins* and *Lato.* https://fonts.google.com/
- Mozilla Developer Network. *Fetch API.* https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
- Mozilla Developer Network. *The dialog element.* https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog
- Mozilla Developer Network. *Client-side form validation.* https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation
- Mozilla Developer Network. *ARIA: aria-expanded attribute* and *Content Security Policy (CSP).* https://developer.mozilla.org/
- W3C. *ARIA Authoring Practices Guide: Accordion pattern.* https://www.w3.org/WAI/ARIA/apg/patterns/accordion/
- Leaflet. *Leaflet 1.9.4 documentation.* https://leafletjs.com/reference.html
- OpenStreetMap contributors. *OpenStreetMap.* https://www.openstreetmap.org/copyright
- Google Search Central. *SEO Starter Guide, Title links, Meta descriptions, robots.txt and Sitemaps.* https://developers.google.com/search/docs
- Schema.org. *AnimalShelter.* https://schema.org/AnimalShelter
- The Open Graph protocol. https://ogp.me/
- Netlify. *Forms setup* and *Custom headers.* https://docs.netlify.com/
